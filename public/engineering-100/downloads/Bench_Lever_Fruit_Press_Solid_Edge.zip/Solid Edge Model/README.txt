PEDESTAL LEVER FRUIT PRESS - SOLID EDGE CONCEPT
ENGG 100 | October 20, 2026

OPEN
Extract the entire ZIP, then open Bench_Lever_Fruit_Press.asm in Solid Edge
2026. Keep all eight .par files beside the assembly. All parts use editable
Ordered features and the course Engineering_ANSI_mm/ansi metric part.par
template; the assembly uses its matching course assembly template.
The extracted templates were checked against Engineering Templates v12.zip.

INTERPRETATION OF THE SKETCH
The supplied image.png shows a wide pedestal base, perforated bowl,
collection cone and a single manual lever with open/closed side views.
This model interprets the lever as one hinged arm with an integral convex
pressing head. It follows an arc rather than translating vertically.
The sketch gives no dimensions: all dimensions below are concept assumptions.
A rear clevis, removable pivot retention and a side drain tube make the
otherwise unspecified support, hinge and juice path explicit.

EIGHT COMPONENTS
01_Base: 210 diameter, 14 thick.
02_Pedestal_Frame: tapered post, rear bridge and clevis; post top z=204.
03_Collector_Funnel: spherical upper shell and conical lower collector.
04_Perforated_Basket: hemispherical bowl, 120 outside diameter, 4 wall;
  130 diameter seating flange, 4 thick, at z=284 to 288.
  Drainage uses 161 vertical holes, diameter 4, on a 7 mm grid.
05_Lever_Press_Head: convex pressing head radius 52 with integral curved arm.
06_Pivot_Pin: 12 diameter, 44 grip length with integral head.
07_Pin_Retainer: removable collar, 18 outside diameter, 12 bore, 3 thick.
08_Outlet_Spout: 16 outside diameter, 12 bore, 100 long.
All dimensions are mm. Hinge axis is parallel to Y, centred at x=-84,z=302.
The basket has 56 mm inside radius; the closed head radius is 52 mm.
The idealized pin collar needs a specified retention method in a real build.
The pedestal and bridge represent an integrated fabricated frame, not a
fully detailed weldment or fabrication drawing.

MOTION
The frame, bowl, collector, pin, retainer and outlet are grounded at their
installed locations. The lever/head has one axial hinge relationship and
one planar depth alignment; rotation remains free. There are nine assembly
relationships. The saved state is open, 75 degrees above the closed state.
Use Rotate/drag in the assembly while keeping the hinge relationships to
explore the motion. No driving angular relationship locks its pose.
The web explorer uses sampled native assembly transforms across this range.
Its separate-parts control is a visual inspection arrangement, not a
validated disassembly sequence or a separate native exploded assembly.

VERIFICATION
Eight Ordered solid parts; positive volumes; all feature statuses OK;
millimetre display units. Native interference checks passed at 21 positions
spaced 3.75 degrees between closed and 75 degrees open. See the model and
motion verification CSVs. Discrete checks do not prove continuous clearance.

MODEL IN SOLID EDGE
1. Start every part from the course ANSI mm template in Ordered mode.
2. Extrude the circular base and revolve the tapered pedestal profile.
3. Add the rear bridge and hinge support; cut its clevis slot and pivot bore.
4. Revolve the collector and basket sections. Add the basket rim and holes.
5. Revolve the convex pressing head; extrude the curved arm and hinge eye.
6. Extrude the pin, retaining collar and annular drain tube.
7. Ground the fixed components. Add the hinge axis and depth alignment.
8. Move the lever through several positions and check against the basket rim.

COMPARISON
This has the simplest moving assembly of the four concepts: one hinge,
with no links, gears, screw thread or translating guide. The revolved shells
and curved arm take more feature work than a rectangular frame, however.
The screw-down design has fewer parts (4), the compound lever has 15 unique
parts and 20 occurrences, and the geared design has 21 unique parts and 29
occurrences. These are modeling-effort comparisons, not force/capacity tests.

LIMITS
No pressing-load rating, stress/stability analysis, manufacturing tolerances,
food-contact finish, fatigue or detailed fastening design is established.
Basket sizes differ among the models; visual size is not a performance test.
These are editable concept studies, not finished final-project drawings.
