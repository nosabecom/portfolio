GEARED FRUIT PRESS - SOLID EDGE CONCEPT MODEL
Created October 14, 2026 from the supplied visual reference.

OPEN
Open Geared_Fruit_Press_Complete.asm in Solid Edge 2026. Keep all .par files
beside the assembly. The ZIP contains the complete linked model.

DIMENSIONS (mm)
Basket: 400 outside diameter, 480 high, 3 wall thickness.
Pressing plate: 382 diameter, 18 thick.
Tray: 600 diameter. Support posts: 50 outside / 40 inside diameter.
Lead screw: nominal 36 diameter, 800 long, 6 lead per revolution.
Guide rod: 20 diameter, 800 long. T-handle: 160 overall span.
Gear pair: 20 and 60 teeth, module 3, 20-degree pressure angle,
120 shaft centre distance, 24 face width.
Overall height in the displayed position: about 1546 including the feet.

MECHANISM
The offset T-handle drives the 20-tooth pinion. The 60-tooth gear carries
the rotating threaded nut. The screw and pressing plate translate together.
The off-centre guide rod prevents the plate and screw from rotating.
Two thrust bearing representations and a removable cover surround the drive.
Three handle revolutions produce one nut revolution and 6 mm of plate travel:
2 mm per handle revolution. Gears reverse rotation direction.

SOLID EDGE MOTION
Native 20:60 rotary and 1-turn:6-mm rotary-linear relationships are present.
The input handle parts and pressing plate parts form separate rigid sets.
The moving parts are free from ground constraints; the frame is grounded.
A suppressed plate-to-tray planar relationship is retained as a test driver.
Its displayed-position offset is 454 mm. Unsuppress it and change the offset
slightly to exercise the mechanism, then restore 454 mm and suppress it again
to leave the geared drive free. Do not confuse this test driver with a
permanent plate attachment.
Verification: 0.333333 mm of plate travel caused 20 degrees of nut rotation
and 60 degrees of handle rotation. See motion_verification.json.

BUILDING AND USING THE CONCEPT
The frame uses simple tube and plate geometry. In a physical build, purchasing
matched gears, a screw/nut pair and rated bearings would reduce machining work.
The short handle avoids the central screw during a full turn; its swept grip
envelope has about 5 mm minimum nominal clearance. Consider more clearance
when choosing real grips and accounting for hands, tolerances and deflection.
The reduction lowers operating effort but increases turns: a 400 mm plate
stroke takes 200 handle revolutions. This model has no quick-release nut.
The large basket would be heavy when full; loading and unloading need planning.

MODEL SCOPE
Editable Ordered .par models and a native .asm assembly, with 21 unique parts
and 29 occurrences. All start from the supplied Engineering_ANSI_mm course
templates. Millimetre units and all solid feature statuses were checked.
Gear flanks use segmented involute curves. Male and female threads use a
concept trapezoid with 6 mm lead; they are not certified standard thread forms.
Bearings and bushings are simplified. Fits, fasteners, welds, lubrication,
food-contact finish, fatigue, stability and press load capacity require
detailed engineering before manufacture. No rated pressing capacity is claimed.

PREVIEWS
Geared_Fruit_Press.png: cover fitted.
Geared_Fruit_Press_Gears.png: cover hidden to show the transmission.
