PEDESTAL COMPOUND PRESS
Arslan + Althea | ENGG 100 | October 23, 2026

OPEN
Extract the complete ZIP and open Pedestal_Compound_Press.asm. The matching _Pressed.asm is the lowered pose. Keep all .par files beside the assemblies, including Source_*.par files for the geared design.

MODEL STATUS
16 assembled part types, 21 occurrences. Parts use Ordered geometry and the supplied Engineering_ANSI_mm templates; template hashes were checked against the course ZIP. The two assemblies store grounded poses for concept review. They are not native joint-driven mechanisms yet. The website interpolates the supplied concept poses.

VERIFICATION
Every saved part was reopened and its feature statuses and positive volume checked. Native Solid Edge interference checks passed at 17 positions across the displayed stroke. See part_verification.csv and motion_verification.csv. These are sampled geometric checks, not force, stability or continuous swept-volume analysis.

MERGER
Arslan: broad circular base and tapered raised pedestal. Althea: guided compound lever, square ram, basket and side-drain tray. The collection tray is raised 150 mm and the post extended accordingly.

ASSUMED DIMENSIONS
600 mm base diameter, 16 mm base thickness. Pedestal 150 mm high, 200 mm lower diameter, 130 mm upper diameter. Original 200 mm basket and 184 mm pressing plate retained. Pressing stroke 163.537 mm; lowest plate position remains about 45 mm above the basket floor.

NEXT MODELING STEP
Ground the frame, add the main and link pivots, guide the square ram and connect the height driver. Original component dimensions and native pose data are retained to help lay out these relationships.
