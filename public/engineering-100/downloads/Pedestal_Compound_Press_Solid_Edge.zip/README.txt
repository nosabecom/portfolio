COMPOUND BOWL PRESS
Arslan + Althea | ENGG 100 | October 23, 2026

OPEN
Extract the complete ZIP and open Pedestal_Compound_Press.asm. The matching _Pressed.asm is the lowered pose. Keep all .par files beside the assemblies, including Source_*.par files for the geared design.

MODEL STATUS
16 assembled part types, 21 occurrences. Parts use Ordered geometry and the supplied Engineering_ANSI_mm templates; template hashes were checked against the course ZIP. The two assemblies store grounded poses for concept review. They are not native joint-driven mechanisms yet. The website interpolates the supplied concept poses.

VERIFICATION
Every saved part was reopened and its feature statuses and positive volume checked. Native Solid Edge interference checks passed at 17 positions across the displayed stroke. See part_verification.csv and motion_verification.csv. These are sampled geometric checks, not force, stability or continuous swept-volume analysis.

MERGER
Arslan: hemispherical perforated bowl, spherical/conical collector and juice outlet spout. Althea: compound lever, twin links, square ram and fixed guide. The curved pressing head is derived from Arslan's head with the hinged manual arm suppressed; Althea's linkage now translates this head vertically. This replaces the earlier cylindrical basket/flat plate interpretation.

ASSUMED DIMENSIONS
600 mm base diameter, 16 mm base thickness. Arslan bowl, collector, head and outlet scaled by 5/3, with editable Source_*.par included. Bowl outside diameter 200 mm, inside radius 93.333 mm; convex head radius 86.667 mm. Concentric closed head and bowl have 6.667 mm radial clearance. Pressing stroke 163.537 mm. A tapered support fits beneath the collector. The post is extended 150 mm to accommodate the revised layout.

NEXT MODELING STEP
Ground the frame, add the main and link pivots, guide the square ram and establish travel stops. Detail the bowl mounting, removable connections and load-bearing joints.
