GEARED BERRY PRESS
Nosa + Lyle | ENGG 100 | October 23, 2026

OPEN
Extract the complete ZIP and open Geared_Berry_Press.asm. The matching _Pressed.asm is the lowered pose. Keep all .par files beside the assemblies, including Source_*.par files for the geared design.

MODEL STATUS
19 assembled part types, 22 occurrences. Parts use Ordered geometry and the supplied Engineering_ANSI_mm templates; template hashes were checked against the course ZIP. The two assemblies store grounded poses for concept review. They are not native joint-driven mechanisms yet. The website interpolates the supplied concept poses.

VERIFICATION
Every saved part was reopened and its feature statuses and positive volume checked. Native Solid Edge interference checks passed at 17 positions across the displayed stroke. See part_verification.csv and motion_verification.csv. These are sampled geometric checks, not force, stability or continuous swept-volume analysis.

MERGER
Nosa: 20/60-tooth reduction, rotating nut, translating screw and anti-rotation guide. Lyle: detachable jar, strainer, berry-feed collar and pressing face. The manual lid handle and its mating collar/lid threads are suppressed; the gear drive now moves the lid vertically. The external guide is attached to the cap outside the fruit chamber.

ASSUMED DIMENSIONS AND MOTION
220 mm base diameter. Portal posts 160 mm apart. Gear-drive source parts are quarter-scale linked copies; their editable source files are included. The input axis has a 0.2 mm centre-distance allowance, the nut bushing is recessed 1 mm, the handle shaft is trimmed to clear the crossbar, the visible screw thread has running clearance, and the nut uses a simplified clearance bore instead of a modeled internal thread. Screw lead is 1.5 mm. The 3:1 gear reduction gives 0.5 mm travel per handle turn: 74 mm of travel requires 148 handle turns. Playback compresses time.

LOADING
Raise the pressing lid and load berries through the sloping side inlet into the strainer. Juice drains into the lower jar. The jar, collar and strainer remain removable.

NEXT MODELING STEP
Add native gear and screw coupling, guide the translating cap and establish travel stops. Detailed attachment hardware, seals and pressing-load ratings remain design work.
