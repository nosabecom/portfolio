ARSLAN + ALTHEA - COMPACT RIM PRESS (REV 5)

Open Compact_Rim_Bowl_Press_Rev5.asm.
Keep all linked parts together. Earlier revisions are preserved.

The lever drives the guided pressing head into a perforated fruit basket held
above the collection bowl. A fixed arm and locating ring carry the basket from
the rear frame. Juice drains downward through its perforations into a separate
large bowl. Removing the lower bowl leaves the basket and its support in place.

The wide annulus is trimmed: basket flange 316 -> 240 mm OD; frame ring
328 -> 252 mm OD. The basket retains a 10 mm radial seat and locating lip.
See material_comparison.csv for native solid-volume changes.

Concept dimensions
- Collection bowl: 320 mm body diameter, 225.8 mm height, two grab handles.
- Basket: 216.7 mm maximum body diameter; 240 mm support flange.
- Frame holder: 220 mm clear opening, 252 mm outside diameter, 20 mm support
  thickness, 6 mm locating lip with 0.3 mm radial flange clearance.
- Basket lowest surface is 78.4 mm above the collection bowl rim.
- Rear column: 864 mm; foot/bowl platform: 520 x 440 x 16 mm.
- Head stroke: 163 mm; 15 assembled part types and 20 occurrences.

Native motion
Home > Motors > Simulate Motor > Animation_1 > Go to Start > Play.
Variable Table 1 drives Press_Position; the native solver moves the lever,
twin links and vertical ram. The pressing head and perforated basket body are
retained; the basket rim and frame holder are narrowed in Rev5.
The saved motor is retained from Rev3; on-screen Play has not been rechecked
for Rev5 because desktop control was unavailable. The 51 native solver poses
and the website playback are checked independently.

The companion Compact_Rim_Bowl_Press_Rev5_Bowl_Removed.asm shows the lower
collection bowl lifted 10 mm and pulled forward 430 mm. The basket stays fixed.
The website provides Remove bowl / Replace bowl, motion and exploded states.

Verification
- 51 native solved press positions checked for interference.
- 31 collection-bowl removal positions checked for interference.
- Both assembly states reopened; all 20 occurrences and 22 solved relationships
  resolve locally in the package.
- ZIP extracted to another folder; both assemblies reopened with all 20
  occurrences resolving to those extracted files, without missing references.
- Native feature status, Ordered mode and ANSI mm course template provenance
  checked for all parts. See included verification and provenance records.

Dimensions are assumed concept dimensions. Holder/frame strength, attachments,
pressing loads, manufacturing fits, capacity and fluid performance remain to
be engineered; the interference checks do not establish a safe working load.
