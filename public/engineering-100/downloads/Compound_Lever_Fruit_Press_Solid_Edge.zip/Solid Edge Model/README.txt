COMPOUND LEVER FRUIT PRESS - SOLID EDGE CONCEPT
ENGG 100 | October 19, 2026

OPEN THE MODEL
Extract the complete ZIP first. Open Compound_Lever_Fruit_Press.asm in Solid
Edge 2026, keeping all 15 .par files beside it. Parts use editable Ordered
sketch/extrude/cut features. All parts and the assembly were started from the
course Engineering_ANSI_mm templates. The supplied extracted templates were
verified byte-for-byte against Engineering Templates v12.zip.

SOURCE AND ASSUMPTIONS
Based on the group member's undimensioned IMG_3700.jpeg, labeled Compound
Lever Fruit Press. Dimensions below are assumed for concept comparison;
they are not measurements from the photograph. The mechanism follows the
sketch: fixed post, pivoting handle, link, guided vertical ram, pressing plate,
perforated basket and base. Two link plates and a forked hinge make the
connections explicit. The added tray, support pads and chute provide a juice
path. Pin collars represent retention; detailed fasteners are simplified.

ASSUMED DIMENSIONS (mm)
Base: 560 x 320 x 16, spanning x=-70 to 490.
Post: 50 x 60 x 534, starting at z=16 and ending at z=550.
Main pivot: x=0, z=600. Hinge cheeks: 50 x 70 x 14 each.
Handle: 580 pivot-to-grip-centre, 34 wide, 24 thick.
Handle-to-link pivot radius: 210. Link: 170 between centres, 28 wide,
6 thick, used twice. All three pivot bores: diameter 12.
Ram: 24 square; upper pivot to plate top: 280.
Guide: 76 x 76 x 60 with 26 square bore; z=280 to 340.
Ram axis/basket centre: x=260, y=0.
Plate: diameter 184 x 12. Basket: outside diameter 200, inside diameter
192, overall height 180, 3 thick floor, diameter 8 drainage holes.
Basket bottom: z=30, internal floor: z=33, rim: z=210.
Tray: diameter 240, 6 thick floor, 5 thick rim, 8 high basket support pads.
Chute: 90 x 32 with 4 thick floor; flush seat cut in the tray outlet.

MOTION AND CHECKS
15 unique parts; 20 occurrences; 22 solved assembly relationships.
Three pivot axes, four alignment relationships, and three moving rigid sets
connect the handle, twin links and ram. Fixed frame parts are grounded.
The last planar relationship (number 22, Base to Press plate) drives height.
Its offset is plate-bottom elevation above the base's bottom plane.
Saved raised position: 241.684 mm (approximately +25 degrees handle angle).
Tested lowered position: 78.147 mm (approximately -20 degrees handle angle).
Plate stroke over this interval: 163.537 mm.
Change the driver's offset gradually within that interval to examine motion.
The driver is active so the saved assembly holds its pose. Suppressing the
driver frees the mechanism's one motion degree of freedom.

Native Solid Edge interference checks reported no solid interferences at
19 sampled positions across this interval. All modeled feature statuses are
OK and all 15 parts are Ordered with mm display units. Verification CSVs
record these checks. Discrete checks are not a continuous swept-volume test.
No load capacity, production tolerances, or fully dimensioned drafts are
established by this concept model. The saved open pose leaves about 32 mm
between plate bottom and basket rim. The lowered pose leaves about 45 mm
above the internal floor: it does not press all the way down to the floor.

HOW TO LEARN TO BUILD IT
1. Start each part from Engineering_ANSI_mm/ansi metric part.par in Ordered.
2. Build the base, post, support and guide from rectangles and extrusions.
   Use a second nested rectangle for the guide's square opening.
3. Sketch the handle and link as straight sides with semicircular ends.
   Place the pivot holes, then extrude. Reuse the same link part twice.
4. Extrude the ram's side profile and cut its cross hole. Extrude the circular
   pressing plate separately. In this concept those parts form a rigid set.
5. Build the basket as a floor disk plus annular wall. Cut floor holes and
   two rows of wall holes. A pattern is a useful alternative to drawing
   every repeated hole individually.
6. Build the tray from a disk and annular rim. Add three support pads so
   floor holes have room to drain. Cut a flush outlet seat for the chute.
7. Ground the frame. Add the main pivot, align the ram to the guide, and
   add both link pivots. Leave rotation free at pivots. Fix the depth
   positions so the links sit outside the handle and ram.
8. Add the plate-height driver and check several poses. A correctly placed
   part in one view does not prove the assembly can move without collision.

COMPARISON WITH YOUR GEARED FRUIT PRESS
These are modeling-effort judgments, not grades or a final decision matrix.

LEVER: easier overall, with moderate assembly work.
15 unique parts / 20 occurrences. All solid features in this model are
extrusions and cuts. The main challenge is choosing pivot spacing, link
length, guide height and stroke so the parts do not bind or hit each other.
Most group members can practice on the base, basket, plate, guide or pins;
one member can coordinate the linkage and assembly relationships.

GEARED: harder overall if the teeth, screw and motion are modeled in detail.
The existing native model opens with 21 unique parts / 29 occurrences and
31 solved relationships. The frame and basket are straightforward, but
involute gear profiles, the threaded screw/nut, bearings and coupled
rotary-to-linear relationships add work. Simplified gears and cosmetic
threads would reduce effort if your instructor accepts that representation.
Its existing 20/60 gear pair and 6 mm lead give 2 mm of plate travel per
handle revolution: a 400 mm stroke requires 200 handle revolutions.

For a first team Solid Edge project, the lever is the more manageable of
these two. That does not establish that it is the best of all four concepts;
compare the other two sketches before completing your selection matrix.
The two models also use different assumed basket sizes, so their part counts
and visual sizes are not a comparison of pressing capacity or performance.

MODEL SCOPE
This package supports design exploration and learning. Detailed fastening,
fits, frame stiffness, stability, pressing load and final dimensioned draft
drawings remain design work. It is not a completed final-project submission.
The original geared project files were reviewed without being overwritten.
