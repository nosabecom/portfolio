ARSLAN + ALTHEA — SUSPENDED PRESS WITH REMOVABLE COLLECTION BOWL (REV 3)

Open Suspended_Lever_Bowl_Press_Rev3.asm.
Keep the linked part files together. Original designs and Rev2 are preserved.

The lever, links and guided head are carried by the rear frame. A large curved
collection bowl sits directly below the head. The perforated strainer rests on
the bowl rim, and juice drains downward into the bowl. Two grab handles let the
bowl and strainer lift out together. Lift the strainer separately to empty juice.

Concept dimensions
- Collection bowl: 320 mm body diameter, 225.8 mm height, 6 mm wall and floor.
- Two integral grab handles; overall span across handles 428 mm.
- Rear-frame foot / bowl platform: 520 x 440 x 16 mm.
- Strainer support flange: 316 mm outside diameter, 5 mm thick.
- Press stroke: 163 mm; 14 part types and 19 assembly occurrences.

Native motion
Home > Motors > Simulate Motor > Animation_1 > Go to Start > Play.
The saved Variable Table 1 motor drives Press_Position at 50 mm/s in Active
Assembly update mode. The native solver moves the lever, twin links and ram.
Saved Animation_1 playback was verified in the visible Solid Edge application.

The companion Suspended_Lever_Bowl_Press_Rev3_Bowl_Removed.asm is a saved removal
state: the bowl and strainer are lifted 20 mm and pulled forward 430 mm.
The website also provides a Remove bowl / Replace bowl control.

Verification
- 51 sampled press positions: native relationships solved; no solid interference.
- 31 sampled bowl-removal positions: no solid interference.
- Both native assembly states reopened with all 19 occurrences, 21 solved
  relationships and no missing references; package links resolve locally.
- ZIP extracted to another folder outside school files; both assemblies reopened
  with all 19 occurrences resolving to the extracted copies.
- Part features checked, Ordered mode verified, course ANSI mm template provenance
  retained. See template_provenance.json and the included verification records.

Dimensions are assumed concept dimensions. Pressing loads, material strength,
manufacturing details, capacity and fluid performance have not been validated.
The strainer flange has 4 mm radial overlap on the bowl opening; positive lateral
location and the load-bearing rim details remain to be engineered.
