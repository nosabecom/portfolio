TWIST LID JUICER - FOUR-PART SOLID EDGE CONCEPT
ENGG 100 | October 19, 2026

OPEN
Extract the complete ZIP, then open Twist_Lid_Juicer.asm in Solid Edge 2026.
Keep all four .par files beside both .asm files. Open
Twist_Lid_Juicer_Exploded.asm to see the four components separated.
All parts use editable Ordered features. Both assemblies and every part
start from the supplied Engineering_ANSI_mm course templates. The template
files were checked byte-for-byte against Engineering Templates v12.zip.

FOUR COMPONENTS FROM THE SKETCH
01_Container.par: rounded collection jar with integral mounting lugs.
02_Chute_Collar.par: loading chute, strainer support and internal screw thread.
03_Strainer.par: hemispherical perforated bowl with removable seating flange.
04_Grinder_Lid.par: handle, threaded skirt, stem and pressing face as one part.

SOURCE AND INTERPRETATION
Based on the supplied IMG_8198.jpeg. The user confirmed that twisting the lid
should move its attached pressing face downward into a fixed strainer.
The sketch supplies no dimensions; the dimensions and joint details below
are concept assumptions. The container/chute connection uses three integral
bayonet lugs. The strainer lifts out, and two flange notches engage collar
keys to keep it from turning. These details make the four detachable parts
modelable without adding separate fasteners.

The crosshatched strainer is represented by a perforated solid bowl rather
than individual woven wires. The pressing face and handle are integral to
the grinder lid, as part of the confirmed screw-down interpretation. The
model has no separate cutting blades or additional hidden components.

ASSUMED MAIN DIMENSIONS (mm)
Container body: 110 outside diameter, 150 height, 3 wall and floor thickness.
Rounded bottom outer corner: radius 18. Neck: 104 outside diameter.
Chute collar: 120 body diameter, 70 body height, placed at elevation 130.
Loading lip projects to 78 from the central axis and is 32 wide overall.
Strainer: hemispherical outside radius 43, inside radius 41, 2 wall thickness.
Strainer flange: 95 outside diameter, 3 thick, bottom elevation 153.
Strainer drainage: 113 vertical holes, diameter 2.4, on a 6-spaced grid.
Lid skirt: 96 core outside diameter, 98 crest diameter, 80 inside diameter,
50 skirt height. Lid cap: 122 diameter and 6 thick. Bridge handle: 82 wide.
Integral pressing face: 60 diameter and 6 thick. Central stem: 24 diameter.
Concept screw thread: single start, 6 lead, seven modeled turns on each
mating feature, with entry relief and running clearance. This is not a
certified standard thread specification or a manufacturing fit schedule.

NATIVE ASSEMBLY MOTION
Four occurrences, six solved relationships in the main assembly.
The container, chute collar and strainer are grounded in their installed
positions. The lid has an axial relationship and a native rotary-linear
relationship that couples its own rotation and translation at 6 mm/turn.
A planar relationship holds the displayed lid height.

The height driver is relationship 5: Container to Grinder lid. Its offset
is the lid skirt's bottom elevation above the container's bottom plane.
Saved raised position: 181 mm. Tested lowered position: 157 mm.
Change this offset gradually within that interval to examine the screw motion.
The lid rotates as it moves; lowering through the 24 mm stroke takes four
turns. The pressing face moves from elevation 154 to elevation 130.
Suppressing the height driver frees the remaining screw motion degree of
freedom. The exploded assembly is a separate, stationary display assembly.

VERIFICATION
All four parts are Ordered, have positive solid volumes, display millimetres,
and have feature status OK, including the mating helical features.
All six main assembly relationships solve. Native interference checks found
no interference at 17 positions, sampled every quarter turn over four turns.
The motion and model verification CSVs contain the recorded results.
These are discrete collision checks, not a continuous swept-volume test.

USING THE CONCEPT
Remove the screw lid to load fruit through the chute into the strainer.
Refit and turn the lid to press. The strainer stays keyed to the chute
collar while juice drains into the jar. Unscrew the lid, lift out the
strainer, and unlock the chute collar from the jar to separate the four
components. A liquid-tight seal and pressing force have not been established.
The lower travel limit leaves clearance between the flat pressing face and
curved bowl; it does not bring every part of the bowl into contact with it.

MODELING GUIDE AND GROUP WORK SPLIT
Container - easiest: sketch its wall section, revolve it, then add the three
mounting lugs. Use the existing feature tree to see the curved bottom.

Strainer - moderate: revolve a thin curved section, add the flange, cut
the locating notches, and create repeated drainage holes. A sketch pattern
or feature pattern can make the repeated-hole work easier to manage.

Grinder lid - moderate to demanding: extrude the annular skirt and cap,
add the pressing stem and disk, create the helical protrusion, then make
the bridge handle and its opening. Keep these united as a single part.

Chute collar - largest job: revolve the stepped ring, cut the bayonet
channels, create the matching internal helix, and add the loading lip and
strainer keys. The entrance counterbore clears the jar's curved shoulder.
This component needs the most coordination with the other three parts.

One component per group member is a natural split, but the effort is uneven.
The container member can also help with the assembly, screenshots or drafts.

COMPARISON OF THE THREE DESIGNS SO FAR
Lever press: 15 unique parts / 20 occurrences. Easiest basic part geometry;
mostly sketches, extrusions and cuts. Moderate assembly work because the
link lengths, pivots and sliding ram must stay aligned through a stroke.

This twist-lid juicer: 4 unique parts / 4 occurrences. Fewest assembly parts
and a compact arrangement, but the curved strainer and two mating helices
make a fully detailed model more demanding than its part count suggests.
With simplified thread representations, it could be very manageable.
The detailed version here is moderate overall, with a demanding collar.

Geared press: 21 unique parts / 29 occurrences. Most demanding detailed
model of the three because it adds gear tooth profiles, screw/nut geometry,
bearings and coupled rotary-to-linear motion.

For practicing the basic lab tools, the lever remains the most straightforward.
For a compact four-member division of work, this juicer is appealing if one
member is comfortable with the collar's thread and joint features. Part
count alone does not establish which design presses fruit best. The models
also use different assumed sizes; they are not a capacity comparison.
Wait for the fourth sketch before completing the group's selection matrix.

SCOPE
This is a concept model and learning aid, not the final dimensioned draft
set, design report, or a production-ready assembly. Existing lever and
geared press files were left unchanged.
